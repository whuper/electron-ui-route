import { EventEmitter as EE } from 'events';

function listenerCount(ee, type) {
  return 'listenerCount' in ee ? ee.listenerCount(type) :
                                 EE.listenerCount(ee, type);
}

export default listenerCount;