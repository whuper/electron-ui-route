// in Node of course this is false
function hasLocalStorage() {
  return false;
}

export default hasLocalStorage;