// in Node of course this is false
function isChromeApp() {
  return false;
}

export default isChromeApp;