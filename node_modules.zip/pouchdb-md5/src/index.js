import binaryMd5 from './binaryMd5';
import stringMd5 from './stringMd5';

export {
  binaryMd5,
  stringMd5
};