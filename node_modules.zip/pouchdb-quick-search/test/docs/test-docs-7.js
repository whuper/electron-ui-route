'use strict';

module.exports = [
  {
    _id : '1',
    text : 'This is text in English about the spleen, which is an organ.'
  },
  {
    _id: '2',
    text: 'Ça c\'est du texte français qui parle du spleen, ce qui veut dire ennui.'
  },
  {
    _id: '3',
    text: 'I am working.'
  }
];