'use strict';

module.exports = [
  {
    _id: '1',
    text: 'words mentioned a lot words'
  },
  {
    _id: '2',
    text: 'words mentioned a lot happy'
  },
];