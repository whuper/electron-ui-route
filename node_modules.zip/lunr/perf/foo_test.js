bench('addition', function () {
  return 1 + 1
})

bench('subtraction', function () {
  return 1 - 1
})
