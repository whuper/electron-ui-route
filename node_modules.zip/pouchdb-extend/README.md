pouchdb-extend
===============

extend() method taken from JQuery 1.9.0 for use in PouchDB

We use this because other extend libraries have been shown 
to not play nicely with Ember.js and IndexedDB
(see [pouchdb/pouchdb#2158](https://github.com/pouchdb/pouchdb/issues/2158)).
