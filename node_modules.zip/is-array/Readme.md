<a href="https://jepso-ci.com/yields/isArray">
  <img src="https://jepso-ci.com/yields/isArray.svg" align="right" alt="jepso-ci status" />
</a>
# isArray

  Check if the given `value` is an `Array`.

## Installation

    $ component install yields/isArray

## API

### isArray(val)

```javascript
isArray(arguments);
// > false
isArray();
// > false
isArray([]);
// > true
```

## License

  MIT
