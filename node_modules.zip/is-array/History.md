
1.0.0 / 2013-02-01 
==================

  * Merge pull request #2 from jepso-ci-4-all/master
  * Add jepso-ci badge to readme
  * Merge pull request #1 from jepso-ci-4-all/master
  * Add jepso-ci
  * Add tests
  * remove es5 from readme confuses ppl
  * use Array.isArray if exists.
