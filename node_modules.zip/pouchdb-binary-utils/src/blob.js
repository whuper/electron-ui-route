// This function is unused in Node
/* istanbul ignore next */
function createBlob() {
}

export default createBlob;
