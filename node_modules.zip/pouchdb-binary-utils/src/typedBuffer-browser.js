// this is not used in the browser
function typedBuffer() {
}

export default typedBuffer;